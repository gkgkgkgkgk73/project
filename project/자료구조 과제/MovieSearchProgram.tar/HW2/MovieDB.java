import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Genre, Title 을 관리하는 영화 데이터베이스.
 * 
 * MyLinkedList 를 사용해 각각 Genre와 Title에 따라 내부적으로 정렬된 상태를  
 * 유지하는 데이터베이스이다. 
 */


public class MovieDB {
	MyLinkedList<Genre> genreMovieDB;
	MyLinkedListIterator<Genre> genreMovieDBIterator;

	public MovieDB() {
		genreMovieDB = new MyLinkedList<>();
		genreMovieDBIterator = new MyLinkedListIterator<>(genreMovieDB);
    }

    public void insert(MovieDBItem item) {
		int i;
		Genre newGenre = new Genre(item);
		if(genreMovieDB.size()==0){
			genreMovieDB.add(newGenre);
		}
		else {
			i=0;
			while (i < genreMovieDB.size() && !genreMovieDB.getNode(i).getItem().equals(newGenre)) {
				i++;
			}
			if (i < genreMovieDB.size()) {
				int k = 0;
				while (k <genreMovieDB.getNode(i).getItem().movieNameList.size() && genreMovieDB.getNode(i).getItem().movieNameList.getNode(k).getItem().compareTo(item) < 0) {
					k++;
				}
				if (k == genreMovieDB.getNode(i).getItem().movieNameList.size()) {
					genreMovieDB.getNode(i).getItem().movieNameList.add(item);
				} else if (k < genreMovieDB.getNode(i).getItem().movieNameList.size() && genreMovieDB.getNode(i).getItem().movieNameList.getNode(k).getItem().compareTo(item) == 0) {
				} else if (k < genreMovieDB.getNode(i).getItem().movieNameList.size() && genreMovieDB.getNode(i).getItem().movieNameList.getNode(k).getItem().compareTo(item) > 0) {
					genreMovieDB.getNode(i).getItem().movieNameList.addI(k, item);
				}
			} else {
				i = 0;
				while (i < genreMovieDB.size() && genreMovieDB.getNode(i).getItem().compareTo(newGenre) < 0) {
					i++;
				}
				genreMovieDB.addI(i, newGenre);
			}
		}
    }

    public void delete(MovieDBItem item) {
		int i;
		Genre newGenre = new Genre(item);
		if(genreMovieDB.size()==0){
		}
		else {
			i=0;
			while (i < genreMovieDB.size() && !genreMovieDB.getNode(i).getItem().equals(newGenre)) {
				i++;
			}
			if (i < genreMovieDB.size()) {
				int k = 0;
				while (k <genreMovieDB.getNode(i).getItem().movieNameList.size() && !genreMovieDB.getNode(i).getItem().movieNameList.getNode(k).getItem().equals(item)) {
					k++;
				}
				if (k == genreMovieDB.getNode(i).getItem().movieNameList.size()) {

				} else{
					genreMovieDB.getNode(i).getItem().movieNameList.remove(k);
				}
			}
		}

    }

    public MyLinkedList<MovieDBItem> search(String term) {
        MyLinkedList<MovieDBItem> results = new MyLinkedList<MovieDBItem>();
        for(Genre g: genreMovieDB){
        	for(MovieDBItem m: g.movieNameList){
        		if(m.getTitle().contains(term)){
        			results.add(m);
				}
			}
		}
        return results;
    }
    
    public MyLinkedList<MovieDBItem> items() {
        MyLinkedList<MovieDBItem> results = new MyLinkedList<>();
        for(Genre g: genreMovieDB){
        	results.link(g.movieNameList);
		}
    	return results;
    }
}

class Genre extends Node<String> implements Comparable<Genre> {

	MyLinkedList<MovieDBItem> movieNameList;

	public void addMovie(MovieDBItem item){
		for(int i=0;i<movieNameList.size();i++){
			if(movieNameList.getNode(i).getItem().compareTo(item)>0){
				movieNameList.addI(i,item);
				return;
			}else if(movieNameList.getNode(i).getItem().compareTo(item)==0){
				return ;
			}
		}
	}

	public Genre(MovieDBItem item){
		super(item.getGenre());
		movieNameList = new MyLinkedList<>();
		movieNameList.add(item);
	}

	
	@Override
	public int compareTo(Genre o) {
		for(int i=0;i<getItem().length() && i<o.getItem().length();i++){
			if((getItem().charAt(i)-'0')>(o.getItem().charAt(i)-'0')){
				return 1;
			}else if((getItem().charAt(i)-'0')<(o.getItem().charAt(i)-'0')){
				return -1;
			}
		}
		if(getItem().length()>o.getItem().length()){
			return 1;
		}else if(getItem().length()<o.getItem().length()){
			return -1;
		}else return 0;
	}

	@Override
	public int hashCode() {
		throw new UnsupportedOperationException("not implemented yet");
	}

	public boolean equals(Genre obj) {
		return (getItem().compareTo(obj.getItem())==0);
	}

	@Override
	public boolean equals(Object obj){
		Genre newGenre = (Genre) obj;
		return equals(newGenre);
	}
}
