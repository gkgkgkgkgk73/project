
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MyLinkedList<T> implements ListInterface<T> {
	// dummy head
	Node<T> head;
	int numItems;

	public MyLinkedList() {
		head = new Node<T>(null);
		numItems =0;
	}

    /**
     * {@code Iterable<T>}를 구현하여 iterator() 메소드를 제공하는 클래스의 인스턴스는
     * 다음과 같은 자바 for-each 문법의 혜택을 볼 수 있다.
     * 
     * <pre>
     *  for (T item: iterable) {
     *  	item.someMethod();
     *  }
     * </pre>
     * 
     * @see PrintCmd#apply(MovieDB)
     * @see SearchCmd#apply(MovieDB)
     * @see java.lang.Iterable#iterator()
     */
    public final Iterator<T> iterator() {
    	return new MyLinkedListIterator<T>(this);
    }

	@Override
	public boolean isEmpty() {
		return head.getNext() == null;
	}

	@Override
	public int size() {
		return numItems;
	}

	@Override
	public T first() {
		return head.getNext().getItem();
	}

	@Override
	public void add(T item){
		Node<T> last = head;

		while (last.getNext()!=null) {
			last = last.getNext();
		}
		last.insertNext(item);
		numItems += 1;
	}

	@Override
	public void removeAll() {
		head.setNext(null);
	}

	public void link(MyLinkedList<T> list) {
		MyLinkedListIterator<T> listIterator = new MyLinkedListIterator<>(list);
		for (T l : list) {
    		add(l);
    		numItems++;
		}
	}


	/*아래 구현된 함수는 모두 수업 자료*/

	public Node<T> getNode(int k){
		if(k>=-1&&k<=numItems-1){
			Node<T> curr = head;
			for(int i=0;i<=k;i++){
				curr = curr.getNext();
			}
			return curr;
		}
		return null;
	}

	public void remove(int k){
		if(k>=0 && k<=numItems-1){
			Node<T> prevNode = getNode(k-1);
			Node<T> currNode = prevNode.getNext();
			prevNode.setNext(currNode.getNext());
			numItems--;
		}
	}

	public void addI(int k, T item){
		if(k>=0&&k<=numItems){
			Node<T> preNode = getNode(k-1);
			Node<T> newNode = new Node<>(item,preNode.getNext());
			preNode.setNext(newNode);
			numItems++;
		}
	}
/*여기까지 수업 자료 참고*/

}

class MyLinkedListIterator<T> implements Iterator<T> {
	// FIXME implement this
	private MyLinkedList<T> list;
	private Node<T> curr;
	private Node<T> prev;

	public MyLinkedListIterator(MyLinkedList<T> list) {
		this.list = list;
		this.curr = list.head;
		this.prev = null;
	}

	@Override
	public boolean hasNext() {
		return (curr.getNext() != null);
	}

	@Override
	public T next() {
		if (!hasNext())
			throw new NoSuchElementException();

		prev = curr;
		curr = curr.getNext();

		return curr.getItem();
	}

	@Override
	public void remove() {
		if (prev == null)
			throw new IllegalStateException("next() should be called first");
		if (curr == null)
			throw new NoSuchElementException();
		prev.removeNext();
		list.numItems -= 1;
		curr = prev;
	}

}